import { useState, useMemo, useEffect } from 'react';
import { Toaster, toast } from 'react-hot-toast';
import { 
  LogIn, 
  LogOut, 
  Clock, 
  Coffee, 
  AlertTriangle, 
  History as HistoryIcon, 
  User as UserIcon,
  QrCode,
  MapPin,
  Smartphone,
  Settings as SettingsIcon,
  Users,
  BarChart3,
  ChevronRight,
  ShieldCheck,
  Calendar as CalendarIcon,
  Search,
  Home,
  X,
  Trash2,
  Filter,
  CheckCircle2,
  Plus,
  ListTodo,
  MoreVertical
} from 'lucide-react';
import { format, startOfDay, endOfDay, isWithinInterval, isSameDay, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { QRScanner } from './components/QRScanner';
import { AttendanceType, UserProfile, AttendanceLog } from './types';
import { motion, AnimatePresence } from 'motion/react';
import { v4 as uuidv4 } from 'uuid';

// --- Styles for Calendar Overrides ---
const calendarStyles = `
  .react-calendar {
    width: 100%;
    border: none;
    background: white;
    font-family: inherit;
    border-radius: 24px;
    padding: 16px;
    box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
  }
  .react-calendar__tile--active {
    background: black !important;
    border-radius: 12px;
  }
  .react-calendar__tile--now {
    background: #f3f4f6;
    border-radius: 12px;
    color: black;
  }
  .react-calendar__navigation button {
    font-weight: bold;
    color: black;
  }
  .has-logs {
    position: relative;
  }
  .has-logs::after {
    content: '';
    position: absolute;
    bottom: 4px;
    left: 50%;
    transform: translateX(-50%);
    width: 4px;
    height: 4px;
    background: #10b981;
    border-radius: 50%;
  }
  .has-anomaly::after {
    background: #f59e0b;
  }
`;

function AdminDashboard() {
  const { allUsers, attendanceLogs, settings, tasks, updateCompanySettings, updateUserSettings, createTask, updateTask } = useAuth();
  const [activeTab, setActiveTab] = useState<'users' | 'logs' | 'tasks' | 'settings'>('users');
  const [searchTerm, setSearchTerm] = useState('');
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [newTask, setNewTask] = useState({ title: '', description: '', assignedTo: '', priority: 'medium' as const, dueDate: format(new Date(), 'yyyy-MM-dd') });

  const stats = useMemo(() => {
    const today = new Date();
    const todayLogs = attendanceLogs.filter(log => 
      isWithinInterval(new Date(log.timestamp), { start: startOfDay(today), end: endOfDay(today) })
    );
    const anomalies = todayLogs.filter(l => l.isAnomaly).length;
    return {
      totalToday: todayLogs.length,
      anomalies,
      activeUsers: allUsers.filter(u => u.status === 'active').length
    };
  }, [attendanceLogs, allUsers]);

  const filteredUsers = allUsers.filter(u => 
    u.displayName.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8 pb-20">
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Hoy', value: stats.totalToday, icon: HistoryIcon, color: 'text-blue-600' },
          { label: 'Anomalías', value: stats.anomalies, icon: AlertTriangle, color: 'text-amber-600' },
          { label: 'Staff', value: stats.activeUsers, icon: Users, color: 'text-green-600' },
        ].map((s, i) => (
          <div key={i} className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm">
            <s.icon size={16} className={`${s.color} mb-2`} />
            <p className="text-2xl font-black">{s.value}</p>
            <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="flex gap-2 bg-gray-100 p-1 rounded-2xl overflow-x-auto no-scrollbar">
        {(['users', 'logs', 'tasks', 'settings'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-2 px-4 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all whitespace-nowrap ${
              activeTab === tab ? 'bg-white shadow-sm text-black' : 'text-gray-400'
            }`}
          >
            {tab === 'users' ? 'Staff' : tab === 'logs' ? 'Historial' : tab === 'tasks' ? 'Tareas' : 'Ajustes'}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'users' && (
          <motion.div key="users" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="text" 
                placeholder="Buscar..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-white border border-gray-100 rounded-2xl py-3 pl-12 pr-4 text-sm outline-none"
              />
            </div>
            <div className="space-y-2">
              {filteredUsers.map(u => (
                <div key={u.uid} className="bg-white p-4 rounded-2xl border border-gray-100 flex items-center justify-between">
                  <div>
                    <p className="font-bold text-gray-900">{u.displayName}</p>
                    <p className="text-xs text-gray-500">{u.email}</p>
                  </div>
                  <select 
                    value={u.status || 'active'}
                    onChange={(e) => updateUserSettings(u.uid, { status: e.target.value as any })}
                    className="text-xs font-bold bg-gray-50 border-none rounded-lg p-1"
                  >
                    <option value="active">Activo</option>
                    <option value="inactive">Inactivo</option>
                  </select>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'logs' && (
          <motion.div key="logs" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">
            {(Object.entries(
              attendanceLogs.reduce((acc, log) => {
                const date = format(new Date(log.timestamp), 'yyyy-MM-dd');
                const key = `${log.uid}_${date}`;
                if (!acc[key]) acc[key] = { userName: log.userName, date, logs: [] };
                acc[key].logs.push(log);
                return acc;
              }, {} as Record<string, { userName: string, date: string, logs: AttendanceLog[] }>)
            ) as [string, { userName: string, date: string, logs: AttendanceLog[] }][])
              .sort((a, b) => b[1].date.localeCompare(a[1].date))
              .map(([key, group]) => {
              const sortedLogs = [...group.logs].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
              const clockIn = sortedLogs.find(l => l.type === 'clock-in');
              const clockOut = [...sortedLogs].reverse().find(l => l.type === 'clock-out');
              const lunchOut = sortedLogs.find(l => l.type === 'lunch-out');
              const lunchIn = sortedLogs.find(l => l.type === 'lunch-in');

              let workMs = 0;
              let lunchMs = 0;
              if (clockIn && clockOut) workMs = new Date(clockOut.timestamp).getTime() - new Date(clockIn.timestamp).getTime();
              if (lunchOut && lunchIn) lunchMs = new Date(lunchIn.timestamp).getTime() - new Date(lunchOut.timestamp).getTime();
              const effectiveMs = workMs > 0 ? Math.max(0, workMs - lunchMs) : 0;

              const formatMs = (ms: number) => {
                const h = Math.floor(ms / 3600000);
                const m = Math.floor((ms % 3600000) / 60000);
                return `${h}h ${m}m`;
              };

              return (
                <div key={key} className="bg-white rounded-3xl border border-gray-100 overflow-hidden shadow-sm">
                  <div className="bg-gray-50 px-4 py-3 border-b border-gray-100 flex justify-between items-center">
                    <div>
                      <p className="text-xs font-black text-gray-900">{group.userName}</p>
                      <p className="text-[10px] text-gray-400 font-bold uppercase">{format(parseISO(group.date), 'd MMM yyyy', { locale: es })}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-black text-green-600">{formatMs(effectiveMs)}</p>
                      <p className="text-[8px] text-gray-400 font-bold uppercase">Efectivo</p>
                    </div>
                  </div>
                  <div className="p-4 space-y-2">
                    {sortedLogs.map(log => (
                      <div key={log.id} className="flex items-center justify-between text-[10px]">
                        <div className="flex items-center gap-2">
                          <div className={`w-1.5 h-1.5 rounded-full ${log.type === 'clock-in' ? 'bg-green-500' : log.type === 'clock-out' ? 'bg-red-500' : 'bg-blue-500'}`} />
                          <span className="font-bold text-gray-600 capitalize">{log.type.replace('-', ' ')}</span>
                        </div>
                        <span className="font-mono text-gray-400">{format(new Date(log.timestamp), 'HH:mm')}</span>
                      </div>
                    ))}
                    {lunchMs > 0 && (
                      <div className="pt-2 mt-2 border-t border-dashed border-gray-100 flex justify-between text-[9px] font-bold text-orange-500">
                        <span>TIEMPO COMIDA</span>
                        <span>{formatMs(lunchMs)}</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}

        {activeTab === 'tasks' && (
          <motion.div key="tasks" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-black uppercase tracking-widest">Asignación de Tareas</h3>
              <button 
                onClick={() => setShowTaskModal(true)}
                className="bg-black text-white p-2 rounded-xl flex items-center gap-2 text-[10px] font-bold"
              >
                <Plus size={14} /> Nueva Tarea
              </button>
            </div>

            <div className="space-y-3">
              {tasks.map(task => (
                <div key={task.id} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm">
                  <div className="flex justify-between items-start mb-2">
                    <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full ${
                      task.priority === 'high' ? 'bg-red-100 text-red-600' : 
                      task.priority === 'medium' ? 'bg-amber-100 text-amber-600' : 'bg-blue-100 text-blue-600'
                    }`}>
                      {task.priority}
                    </span>
                    <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full ${
                      task.status === 'done' ? 'bg-green-100 text-green-600' : 
                      task.status === 'in-progress' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-400'
                    }`}>
                      {task.status}
                    </span>
                  </div>
                  <h4 className="font-bold text-gray-900 text-sm mb-1">{task.title}</h4>
                  <p className="text-xs text-gray-500 mb-3 line-clamp-2">{task.description}</p>
                  <div className="flex justify-between items-center pt-3 border-t border-gray-50">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center text-[10px] font-bold">
                        {task.assignedToName.charAt(0)}
                      </div>
                      <span className="text-[10px] font-bold text-gray-600">{task.assignedToName}</span>
                    </div>
                    <span className="text-[10px] text-gray-400 font-bold">{format(parseISO(task.dueDate), 'd MMM')}</span>
                  </div>
                </div>
              ))}
            </div>

            {showTaskModal && (
              <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-sm flex items-center justify-center p-6">
                <div className="bg-white w-full max-w-md rounded-[2rem] p-8 space-y-4">
                  <h3 className="text-xl font-black">Asignar Tarea</h3>
                  <div className="space-y-3">
                    <input 
                      type="text" 
                      placeholder="Título de la tarea"
                      value={newTask.title}
                      onChange={e => setNewTask({...newTask, title: e.target.value})}
                      className="w-full bg-gray-50 rounded-xl p-3 text-sm font-bold outline-none"
                    />
                    <textarea 
                      placeholder="Descripción..."
                      value={newTask.description}
                      onChange={e => setNewTask({...newTask, description: e.target.value})}
                      className="w-full bg-gray-50 rounded-xl p-3 text-sm font-bold outline-none h-24 resize-none"
                    />
                    <select 
                      value={newTask.assignedTo}
                      onChange={e => setNewTask({...newTask, assignedTo: e.target.value})}
                      className="w-full bg-gray-50 rounded-xl p-3 text-sm font-bold outline-none"
                    >
                      <option value="">Asignar a...</option>
                      {allUsers.map(u => <option key={u.uid} value={u.uid}>{u.displayName}</option>)}
                    </select>
                    <div className="grid grid-cols-2 gap-3">
                      <select 
                        value={newTask.priority}
                        onChange={e => setNewTask({...newTask, priority: e.target.value as any})}
                        className="bg-gray-50 rounded-xl p-3 text-sm font-bold outline-none"
                      >
                        <option value="low">Baja</option>
                        <option value="medium">Media</option>
                        <option value="high">Alta</option>
                      </select>
                      <input 
                        type="date"
                        value={newTask.dueDate}
                        onChange={e => setNewTask({...newTask, dueDate: e.target.value})}
                        className="bg-gray-50 rounded-xl p-3 text-sm font-bold outline-none"
                      />
                    </div>
                  </div>
                  <div className="flex gap-3 pt-4">
                    <button onClick={() => setShowTaskModal(false)} className="flex-1 py-3 text-gray-400 font-bold">Cancelar</button>
                    <button 
                      onClick={async () => {
                        const assignedUser = allUsers.find(u => u.uid === newTask.assignedTo);
                        await createTask({
                          ...newTask,
                          assignedToName: assignedUser?.displayName || 'N/A',
                          status: 'todo'
                        });
                        setShowTaskModal(false);
                        toast.success('Tarea asignada');
                      }}
                      className="flex-1 bg-black text-white py-3 rounded-xl font-bold"
                    >
                      Crear Tarea
                    </button>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'settings' && (
          <motion.div key="settings" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="bg-white p-6 rounded-3xl border border-gray-100 space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Entrada</label>
                <input type="time" value={settings?.workStart} onChange={(e) => updateCompanySettings({ workStart: e.target.value })} className="w-full bg-gray-50 rounded-xl p-3 text-sm font-bold" />
              </div>
              <div>
                <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Salida</label>
                <input type="time" value={settings?.workEnd} onChange={(e) => updateCompanySettings({ workEnd: e.target.value })} className="w-full bg-gray-50 rounded-xl p-3 text-sm font-bold" />
              </div>
            </div>
            <div>
              <label className="text-[10px] font-bold text-gray-400 uppercase block mb-1">Secreto QR</label>
              <div className="flex gap-2">
                <input type="text" value={settings?.qrSecret} readOnly className="flex-1 bg-gray-50 rounded-xl p-3 text-xs font-mono" />
                <button onClick={() => updateCompanySettings({ qrSecret: uuidv4().slice(0, 8).toUpperCase() })} className="bg-black text-white px-4 rounded-xl text-xs font-bold">Regenerar</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function AttendanceApp() {
  const { user, profile, loading, login, logout, registerAttendance, attendanceLogs, tasks, updateTask } = useAuth();
  const [showScanner, setShowScanner] = useState(false);
  const [selectedType, setSelectedType] = useState<AttendanceType | null>(null);
  const [activeView, setActiveView] = useState<'home' | 'calendar' | 'tasks' | 'history' | 'admin'>('home');
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [dismissedLogs, setDismissedLogs] = useState<string[]>(() => {
    const saved = localStorage.getItem('dismissed_logs');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('dismissed_logs', JSON.stringify(dismissedLogs));
  }, [dismissedLogs]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }} className="w-12 h-12 border-4 border-black border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-md w-full bg-white rounded-3xl shadow-xl p-8 text-center">
          <div className="w-20 h-20 bg-black text-white rounded-2xl flex items-center justify-center mx-auto mb-6"><Clock size={40} /></div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Tracker de Ingreso</h1>
          <p className="text-gray-600 mb-8">Inicia sesión para registrar tu jornada laboral.</p>
          <button onClick={login} className="w-full bg-black text-white py-4 rounded-2xl font-semibold flex items-center justify-center gap-3 active:scale-95 transition-all"><LogIn size={20} />Continuar con Google</button>
        </motion.div>
      </div>
    );
  }

  const handleScan = async (data: string) => {
    if (selectedType) {
      try {
        await registerAttendance(selectedType, data);
        toast.success('Registro exitoso');
        setShowScanner(false);
        setSelectedType(null);
      } catch (error: any) {
        toast.error(error.message || 'Error al registrar');
      }
    }
  };

  const dismissLog = (id: string) => {
    setDismissedLogs(prev => [...prev, id]);
    toast.success('Registro ocultado de la app');
  };

  const visibleLogs = attendanceLogs.filter(log => !dismissedLogs.includes(log.id!));
  
  const calculateDayDurations = (logs: AttendanceLog[]) => {
    const sorted = [...logs].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    const clockIn = sorted.find(l => l.type === 'clock-in');
    const clockOut = [...sorted].reverse().find(l => l.type === 'clock-out');
    const lunchOut = sorted.find(l => l.type === 'lunch-out');
    const lunchIn = sorted.find(l => l.type === 'lunch-in');

    let totalShiftMs = 0;
    let lunchMs = 0;

    if (clockIn && clockOut) {
      totalShiftMs = new Date(clockOut.timestamp).getTime() - new Date(clockIn.timestamp).getTime();
    }

    if (lunchOut && lunchIn) {
      lunchMs = new Date(lunchIn.timestamp).getTime() - new Date(lunchOut.timestamp).getTime();
    }

    const effectiveWorkMs = totalShiftMs > 0 ? Math.max(0, totalShiftMs - lunchMs) : 0;

    const formatMs = (ms: number) => {
      if (ms <= 0) return '--:--';
      const hours = Math.floor(ms / (1000 * 60 * 60));
      const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
      return `${hours}h ${minutes}m`;
    };

    return {
      totalShift: formatMs(totalShiftMs),
      lunchTime: formatMs(lunchMs),
      effectiveWork: formatMs(effectiveWorkMs),
      hasClockOut: !!clockOut
    };
  };

  const todayLogs = visibleLogs.filter(l => isSameDay(new Date(l.timestamp), new Date()));
  const todayStats = calculateDayDurations(todayLogs);
  const logsForSelectedDate = visibleLogs.filter(log => isSameDay(new Date(log.timestamp), selectedDate));
  const selectedDateStats = calculateDayDurations(logsForSelectedDate);

  const attendanceButtons = [
    { type: 'clock-in' as AttendanceType, label: 'Entrada', icon: LogIn, color: 'bg-green-500' },
    { type: 'lunch-out' as AttendanceType, label: 'Comida (S)', icon: Coffee, color: 'bg-orange-500' },
    { type: 'lunch-in' as AttendanceType, label: 'Comida (R)', icon: Clock, color: 'bg-blue-500' },
    { type: 'clock-out' as AttendanceType, label: 'Salida', icon: LogOut, color: 'bg-red-500' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <style>{calendarStyles}</style>
      
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-4 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-black text-white rounded-xl flex items-center justify-center"><Clock size={24} /></div>
            <div>
              <h2 className="font-bold text-gray-900 leading-tight">{profile?.displayName}</h2>
              <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest">{profile?.role}</p>
            </div>
          </div>
          <button onClick={logout} className="p-2 text-gray-300 hover:text-red-500 transition-colors"><LogOut size={20} /></button>
        </div>
      </header>

      <main className="flex-1 max-w-2xl w-full mx-auto p-6 overflow-y-auto pb-24">
        <AnimatePresence mode="wait">
          {activeView === 'home' && (
            <motion.div key="home" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} className="space-y-8">
              {todayLogs.length > 0 && (
                <section className="grid grid-cols-2 gap-4">
                  <div className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                      <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest">Jornada Neta</p>
                    </div>
                    <p className="text-2xl font-black text-gray-900">{todayStats.effectiveWork}</p>
                    <p className="text-[9px] text-gray-400 mt-1 font-medium">Total trabajado hoy</p>
                  </div>
                  <div className="bg-white p-5 rounded-[2rem] border border-gray-100 shadow-sm">
                    <div className="flex items-center gap-2 mb-2">
                      <Coffee size={12} className="text-orange-500" />
                      <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest">Descanso</p>
                    </div>
                    <p className="text-2xl font-black text-gray-900">{todayStats.lunchTime}</p>
                    <p className="text-[9px] text-gray-400 mt-1 font-medium">Tiempo de comida</p>
                  </div>
                </section>
              )}

              <section>
                <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-4">Registro Rápido</h3>
                <div className="grid grid-cols-2 gap-4">
                  {attendanceButtons.map((btn) => (
                    <button
                      key={btn.type}
                      onClick={() => { setSelectedType(btn.type); setShowScanner(true); }}
                      className="bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100 flex flex-col items-center gap-3 hover:shadow-md transition-all active:scale-95 group"
                    >
                      <div className={`w-12 h-12 ${btn.color} text-white rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform`}><btn.icon size={24} /></div>
                      <span className="font-bold text-gray-700">{btn.label}</span>
                    </button>
                  ))}
                </div>
              </section>

              <section className="bg-black text-white rounded-[2rem] p-6 relative overflow-hidden">
                <div className="relative z-10">
                  <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest mb-1">Dispositivo ID</p>
                  <p className="font-mono text-xs opacity-60">{profile?.deviceId?.slice(0, 24)}...</p>
                </div>
                <Smartphone className="absolute -right-4 -bottom-4 opacity-10" size={80} />
              </section>

              <section>
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">Actividad de Hoy</h3>
                  <HistoryIcon size={14} className="text-gray-300" />
                </div>
                <div className="space-y-3">
                  {visibleLogs.filter(l => isSameDay(new Date(l.timestamp), new Date())).length === 0 ? (
                    <div className="text-center py-10 bg-white rounded-3xl border border-dashed border-gray-200"><p className="text-gray-400 text-sm">Sin actividad hoy</p></div>
                  ) : (
                    visibleLogs.filter(l => isSameDay(new Date(l.timestamp), new Date())).map(log => (
                      <div key={log.id} className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-center justify-between group">
                        <div className="flex items-center gap-4">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${log.type === 'clock-in' ? 'bg-green-50 text-green-600' : log.type === 'clock-out' ? 'bg-red-50 text-red-600' : 'bg-gray-50 text-gray-600'}`}>
                            {log.type === 'clock-in' ? <LogIn size={18} /> : log.type === 'clock-out' ? <LogOut size={18} /> : <Coffee size={18} />}
                          </div>
                          <div>
                            <p className="font-bold text-gray-900 text-sm capitalize">{log.type.replace('-', ' ')}</p>
                            <p className="text-[10px] text-gray-400 font-bold">{format(new Date(log.timestamp), "HH:mm 'hrs'")}</p>
                          </div>
                        </div>
                        <button onClick={() => dismissLog(log.id!)} className="opacity-0 group-hover:opacity-100 p-2 text-gray-300 hover:text-red-400 transition-all"><Trash2 size={16} /></button>
                      </div>
                    ))
                  )}
                </div>
              </section>
            </motion.div>
          )}

          {activeView === 'calendar' && (
            <motion.div key="calendar" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-6">
              <Calendar 
                onChange={(val) => setSelectedDate(val as Date)} 
                value={selectedDate}
                locale="es-ES"
                tileClassName={({ date }) => {
                  const dayLogs = visibleLogs.filter(l => isSameDay(new Date(l.timestamp), date));
                  if (dayLogs.length > 0) {
                    return dayLogs.some(l => l.isAnomaly) ? 'has-logs has-anomaly' : 'has-logs';
                  }
                  return '';
                }}
              />

              {logsForSelectedDate.length > 0 && (
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-black text-white p-4 rounded-2xl">
                    <p className="text-[8px] uppercase font-bold opacity-60 mb-1">Jornada Efectiva</p>
                    <p className="text-lg font-black">{selectedDateStats.effectiveWork}</p>
                  </div>
                  <div className="bg-gray-100 p-4 rounded-2xl">
                    <p className="text-[8px] uppercase font-bold text-gray-400 mb-1">Tiempo Comida</p>
                    <p className="text-lg font-black text-gray-900">{selectedDateStats.lunchTime}</p>
                  </div>
                </div>
              )}
              
              <div className="space-y-3">
                <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{format(selectedDate, "d 'de' MMMM", { locale: es })}</h4>
                {logsForSelectedDate.length === 0 ? (
                  <p className="text-center py-8 text-gray-400 text-sm">No hay registros para este día</p>
                ) : (
                  logsForSelectedDate.map(log => (
                    <div key={log.id} className="bg-white p-4 rounded-2xl border border-gray-100 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${log.isAnomaly ? 'bg-amber-100 text-amber-600' : 'bg-gray-100 text-gray-600'}`}>
                          {log.isAnomaly ? <AlertTriangle size={14} /> : <Clock size={14} />}
                        </div>
                        <div>
                          <p className="text-xs font-bold capitalize">{log.type.replace('-', ' ')}</p>
                          <p className="text-[10px] text-gray-400">{format(new Date(log.timestamp), 'HH:mm')}</p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          )}

          {activeView === 'tasks' && (
            <motion.div key="tasks" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-black">Mis Tareas</h3>
                <div className="flex gap-2">
                  <span className="bg-gray-100 text-gray-500 text-[10px] font-black px-2 py-1 rounded-lg">
                    {tasks.filter(t => t.status !== 'done').length} PENDIENTES
                  </span>
                </div>
              </div>

              <div className="space-y-4">
                {tasks.length === 0 ? (
                  <div className="text-center py-20 bg-white rounded-[2.5rem] border border-dashed border-gray-200">
                    <ListTodo size={40} className="mx-auto text-gray-200 mb-4" />
                    <p className="text-gray-400 text-sm font-bold uppercase tracking-widest">Sin tareas asignadas</p>
                  </div>
                ) : (
                  tasks.map(task => (
                    <div key={task.id} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm relative overflow-hidden group">
                      <div className={`absolute left-0 top-0 bottom-0 w-1.5 ${
                        task.priority === 'high' ? 'bg-red-500' : 
                        task.priority === 'medium' ? 'bg-amber-500' : 'bg-blue-500'
                      }`} />
                      
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-[8px] font-black uppercase tracking-widest text-gray-400">
                          Vence: {format(parseISO(task.dueDate), 'd MMM')}
                        </span>
                        <select 
                          value={task.status}
                          onChange={(e) => updateTask(task.id!, { status: e.target.value as any })}
                          className={`text-[10px] font-black uppercase px-2 py-1 rounded-lg outline-none border-none ${
                            task.status === 'done' ? 'bg-green-100 text-green-600' : 
                            task.status === 'in-progress' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-500'
                          }`}
                        >
                          <option value="todo">Pendiente</option>
                          <option value="in-progress">En Proceso</option>
                          <option value="done">Completada</option>
                        </select>
                      </div>

                      <h4 className={`font-bold text-gray-900 mb-1 ${task.status === 'done' ? 'line-through opacity-50' : ''}`}>
                        {task.title}
                      </h4>
                      <p className={`text-xs text-gray-500 line-clamp-2 ${task.status === 'done' ? 'opacity-50' : ''}`}>
                        {task.description}
                      </p>
                      
                      {task.status !== 'done' && (
                        <button 
                          onClick={() => updateTask(task.id!, { status: 'done' })}
                          className="mt-4 w-full py-2 bg-gray-50 rounded-xl text-[10px] font-black uppercase tracking-widest text-gray-400 hover:bg-black hover:text-white transition-all"
                        >
                          Marcar como lista
                        </button>
                      )}
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          )}

          {activeView === 'history' && (
            <motion.div key="history" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-black">Historial Completo</h3>
                <button onClick={() => setDismissedLogs([])} className="text-[10px] font-bold text-blue-500 uppercase">Restaurar Ocultos</button>
              </div>
              <div className="space-y-3">
                {visibleLogs.map(log => (
                  <div key={log.id} className="bg-white p-4 rounded-2xl border border-gray-100 flex items-center justify-between group">
                    <div className="flex items-center gap-4">
                      <div className="text-center min-w-[40px]">
                        <p className="text-xs font-black leading-none">{format(new Date(log.timestamp), 'dd')}</p>
                        <p className="text-[8px] uppercase font-bold text-gray-400">{format(new Date(log.timestamp), 'MMM', { locale: es })}</p>
                      </div>
                      <div className="h-8 w-px bg-gray-100" />
                      <div>
                        <p className="text-xs font-bold capitalize">{log.type.replace('-', ' ')}</p>
                        <p className="text-[10px] text-gray-400">{format(new Date(log.timestamp), 'HH:mm')} • {log.isAnomaly ? 'Anomalía' : 'Normal'}</p>
                      </div>
                    </div>
                    <button onClick={() => dismissLog(log.id!)} className="p-2 text-gray-200 hover:text-red-400 transition-all"><X size={16} /></button>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeView === 'admin' && profile?.role === 'admin' && (
            <motion.div key="admin" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}>
              <AdminDashboard />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-gray-100 px-4 py-3 fixed bottom-0 left-0 right-0 z-20">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <NavBtn active={activeView === 'home'} onClick={() => setActiveView('home')} icon={Home} label="Inicio" />
          <NavBtn active={activeView === 'tasks'} onClick={() => setActiveView('tasks')} icon={ListTodo} label="Tareas" />
          <NavBtn active={activeView === 'calendar'} onClick={() => setActiveView('calendar')} icon={CalendarIcon} label="Calendario" />
          <NavBtn active={activeView === 'history'} onClick={() => setActiveView('history')} icon={HistoryIcon} label="Historial" />
          {profile?.role === 'admin' && (
            <NavBtn active={activeView === 'admin'} onClick={() => setActiveView('admin')} icon={ShieldCheck} label="Admin" />
          )}
        </div>
      </nav>

      {/* Scanner Modal */}
      <AnimatePresence>
        {showScanner && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-6">
            <motion.div initial={{ scale: 0.9, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, y: 20 }} className="bg-white w-full max-w-md rounded-[2.5rem] p-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-black">Validar QR</h3>
                <button onClick={() => setShowScanner(false)} className="p-2 bg-gray-100 rounded-full"><X size={20} /></button>
              </div>
              <QRScanner onScan={handleScan} />
              <p className="text-center text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-6">Escanea el código de la oficina</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <Toaster position="top-center" toastOptions={{ style: { borderRadius: '16px', background: '#000', color: '#fff', fontSize: '12px', fontWeight: 'bold' } }} />
    </div>
  );
}

function NavBtn({ active, onClick, icon: Icon, label }: { active: boolean, onClick: () => void, icon: any, label: string }) {
  return (
    <button onClick={onClick} className={`flex flex-col items-center gap-1 transition-all ${active ? 'text-black' : 'text-gray-300'}`}>
      <div className={`p-2 rounded-xl transition-all ${active ? 'bg-gray-100' : ''}`}><Icon size={20} strokeWidth={active ? 2.5 : 2} /></div>
      <span className="text-[8px] font-black uppercase tracking-wider">{label}</span>
    </button>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <AttendanceApp />
      </AuthProvider>
    </ErrorBoundary>
  );
}
